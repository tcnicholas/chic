# CHIC
**C**oarse-graining **H**ybrid **I**organic **C**rystals.


## Installation
    
 ```bash
 conda create -n chic23 python=3.8 -y
 conda activate chic23
 conda install -c conda-forge cython pymatgen -y
 ```

 ## Getting started

Head over to the docs page for chic to see example usuage!

## Authors

Thomas C. Nicholas

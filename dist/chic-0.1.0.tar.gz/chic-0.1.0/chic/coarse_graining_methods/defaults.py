"""
30.07.23
@tcnicholas
Defaults for coarse-graining methods.
"""


def centroid_method1(self):
    pass


def centroid_method2(self):
    pass


methods = {

    'centroid_method1': {
        'func': centroid_method1,
        'bead_type': 'single',
    },

    'centroid_method2': {
        'func': centroid_method2,
        'bead_type': 'single',
    }

}
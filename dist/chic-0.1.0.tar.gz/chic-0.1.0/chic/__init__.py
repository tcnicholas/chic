"""
chic.


A Python library for coarse-graining hybrid and inorganic frameworks.
"""


__version__ = "0.1.0"
__author__ = 'Thomas C Nicholas'